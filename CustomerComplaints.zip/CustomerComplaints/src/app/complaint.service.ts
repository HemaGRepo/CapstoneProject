import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Complaint } from './complaint.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ComplaintService {
  

  private complaintsUrl: string;
  private status: string;
  private deleteUrl: string;
  private feedbckUrl:string;
  private newComplaintUrl:string;
  private assignUrl:string;
  private updateUrl:string;

  constructor(private http: HttpClient) {
    this.complaintsUrl = 'http://localhost:8080/complaints';
    this.status="";
    this.deleteUrl="";
    this.feedbckUrl="";
    this.newComplaintUrl="";
    this.assignUrl="";
    this.updateUrl="";
  }

  public findAll(): Observable<Complaint[]> {
    return this.http.get<Complaint[]>(this.complaintsUrl);
  }

  public save(complaint: Complaint) {
    return this.http.post<Complaint>(this.complaintsUrl, complaint);
  }

  deleteById(id: any) {
    this.deleteUrl = 'http://localhost:8080/complaint/delete/'+id;
    
    this.http.delete(this.deleteUrl)
            .subscribe(() => this.status = 'Delete successful');
  }

  providefeedback(id:any,score:number){
   var fb={"complaintId":id,"score":score};
   this.feedbckUrl = 'http://localhost:8080/feedback';
    
   this.http.post(this.feedbckUrl,fb)
         .subscribe(() => this.status = 'Insert successful');

  }

  raiseComplaint(comp:Complaint){
    this.newComplaintUrl = 'http://localhost:8080/complaint';
    
   this.http.post(this.newComplaintUrl,comp)
         .subscribe(() => this.status = 'Insert successful');
 
   }

   assignEngineer(id:any,pincode:string){

     var eng:Engineer=new Engineer();
     console.log(pincode);
     if(pincode == "600009")
       eng.EngineerId=502;
    if(pincode == "600001")
       eng.EngineerId=501; 

    eng.complaintId=id;
    eng.pinCode=pincode;
      
    this.assignUrl = 'http://localhost:8080/complaint/assign';
    
 this.http.post(this.assignUrl,eng)
       .subscribe(() => this.status = 'Insert successful');
 
   }

   updateStatus(compId: any, status: string) {
    var id:number=compId;
    this.updateUrl = 'http://localhost:8080/complaint/'+id+'/'+status;
    this.http.get(this.updateUrl).subscribe(() => this.status = 'Update successful');
  }
}

class Engineer{
  complaintId:number;
  EngineerId:number;
  pinCode:string;

  constructor(){
    this.complaintId=0;
    this.EngineerId=0;
    this.pinCode="";

  }
}
