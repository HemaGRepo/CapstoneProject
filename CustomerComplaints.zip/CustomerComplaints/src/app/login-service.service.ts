import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './user.model';
import { Observable } from 'rxjs';

@Injectable()
export class UserService {

  private usersUrl: string;
  private deleteUrl: string;
  private status: string;

  constructor(private http: HttpClient) {
    this.usersUrl = 'http://localhost:8080/admin/users';
    this.status="";
    this.deleteUrl="";
  }

  public findAll(): Observable<User[]> {
    return this.http.get<User[]>(this.usersUrl);
  }

  public save(user: User) {
    return this.http.post<User>(this.usersUrl, user);
  }

  deleteByName(name: any) {
    this.deleteUrl = 'http://localhost:8080/admin/delete/'+name;
    
    this.http.delete(this.deleteUrl)
            .subscribe(() => this.status = 'Delete successful');
  }
}