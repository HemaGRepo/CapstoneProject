export interface User {

userId:number;
userName: string;
password: string;
role: string;


}
