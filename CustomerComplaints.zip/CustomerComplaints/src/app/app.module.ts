import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {RouterModule, Routes} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AdminComponent } from './admin/admin.component';
import { ManagerComponent } from './manager/manager.component';
import { CustomerComponent } from './customer/customer.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { EngineerComponent } from './engineer/engineer.component';

@NgModule({
  declarations: [
    AppComponent,LoginComponent,RegisterComponent, AdminComponent, ManagerComponent, 
    CustomerComponent, ViewUserComponent, EngineerComponent
  ],
  imports: [
    BrowserModule,RouterModule,ReactiveFormsModule,FormsModule,HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
