import { Component, OnInit } from '@angular/core';
import { ComplaintService } from '../complaint.service';
import { Complaint } from '../complaint.model';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';


@Component({
  selector: 'app-admin',
  providers: [ComplaintService],
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  complaints: Complaint[];
  
  constructor(private complaintService: ComplaintService,  private route: ActivatedRoute,
    private router: Router) { 
   this.complaints=[];  
  }

  ngOnInit(): void {
    console.log("Fetching...");
    this.complaintService.findAll().subscribe(data => {
      this.complaints = data;
    });
       console.log(this.complaints);
  }

  delete(id:any) {
      console.log(id);
      
      this.complaintService.deleteById(id);

  }

}
