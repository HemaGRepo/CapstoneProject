import { Component, OnInit } from '@angular/core';
import { ComplaintService } from '../complaint.service';
import { Complaint } from '../complaint.model';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-manager',
  providers: [ComplaintService],
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {
  userId:number;
  userName:String;

  complaints: Complaint[];
  
  constructor(private complaintService: ComplaintService,  private route: ActivatedRoute,
    private router: Router) { 
   this.complaints=[];  
   this.userId=0;
   this.userName="";
  }

  ngOnInit(): void {
    console.log("Fetching...");
    this.userId = this.route.snapshot.params['userId'];
    this.userName = this.route.snapshot.params['username'];
    this.complaintService.findAll().subscribe(data => {
      this.complaints = data;
    });
       console.log(this.complaints);
  }

  assign(id:any,pincode:any) {
      console.log(id);
      console.log("In assign Method");
      this.complaintService.assignEngineer(id,pincode);
      console.log("Calling Refresh");
      this.reloadComponent();
  }

  reloadComponent() {
    let currentUrl = this.router.url;
        this.router.routeReuseStrategy.shouldReuseRoute = () => false;
        this.router.onSameUrlNavigation = 'reload';
        this.router.navigate([currentUrl]);
        this.router.navigate(['Manager', { userId: this.userId, username:this.userName}]);
    }
}
