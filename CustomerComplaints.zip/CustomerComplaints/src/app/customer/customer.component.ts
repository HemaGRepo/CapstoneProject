import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { User } from '../user.model';
import { ComplaintService } from '../complaint.service';
import { Complaint } from '../complaint.model';
import { UserService } from '../login-service.service';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-customer',
  providers: [ComplaintService],
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
 
  userId:number;
  userName:String;

  complaintForm = new FormGroup({
    Description: new FormControl(''),
    Pincode: new FormControl('')
  });

  complaints: Complaint[];
  custComp: Complaint[];
  constructor(private complaintService: ComplaintService,private route: ActivatedRoute,
    private router: Router) { 
      this.complaints=[];  
      this.custComp=[]; 
      this.userId=0;
      this.userName="";
  }

  ngOnInit(): void {
    this.userId = this.route.snapshot.params['userId'];
    this.userName = this.route.snapshot.params['username'];
    
    this.complaintService.findAll().subscribe(data => {
      this.complaints = data;
    });

  }

  feedback( id:any,score:number) {
    console.log(id);
    this.complaintService.providefeedback(id,score);
    this.reloadComponent();
    
    }

    addcomplaint() {
      var comp:Complaint = new Complaint();
      comp.complaintId=910;
      comp.status="open";
      comp.customerId=this.userId;
      comp.description =this.complaintForm.value.Description;
      comp.pincode =this.complaintForm.value.Pincode;
      this.complaintService.raiseComplaint(comp);
      this.reloadComponent();
      
    }

    reloadComponent() {
      let currentUrl = this.router.url;
          this.router.routeReuseStrategy.shouldReuseRoute = () => false;
          this.router.onSameUrlNavigation = 'reload';
          this.router.navigate([currentUrl]);
          this.router.navigate(['Customer', { userId: this.userId, username:this.userName}]);
      }

}
