import { Component, OnInit } from '@angular/core';
import { ComplaintService } from '../complaint.service';
import { Complaint } from '../complaint.model';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';


@Component({
  selector: 'app-engineer',
  templateUrl: './engineer.component.html',
  styleUrls: ['./engineer.component.css']
})
export class EngineerComponent implements OnInit {
  userId:number;
  userName:String;

  complaints: Complaint[];
  
  constructor(private complaintService: ComplaintService,  private route: ActivatedRoute,
    private router: Router) { 
   this.complaints=[];  
   this.userId=0;
   this.userName="";
  }

  ngOnInit(): void {
    console.log("Fetching...");
    this.userId = this.route.snapshot.params['userId'];
    this.userName = this.route.snapshot.params['username'];
    this.complaintService.findAll().subscribe(data => {
      this.complaints = data;
    });
       console.log(this.complaints);
  }

  setStatus( id:any,status:string) {
    console.log(id,status);
    this.complaintService.updateStatus(id,status);
    this.reloadComponent();
    
    }

  reloadComponent() {
    let currentUrl = this.router.url;
        this.router.routeReuseStrategy.shouldReuseRoute = () => false;
        this.router.onSameUrlNavigation = 'reload';
        this.router.navigate([currentUrl]);
        this.router.navigate(['Engineer', { userId: this.userId, username:this.userName}]);
    }

}
