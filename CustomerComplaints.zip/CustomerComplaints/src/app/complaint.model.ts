import { Input } from "@angular/core";

export class Complaint {

complaintId: number | undefined;
customerId: number | undefined;
description: string| undefined;
pincode: string| undefined;
status: string| undefined;
}
