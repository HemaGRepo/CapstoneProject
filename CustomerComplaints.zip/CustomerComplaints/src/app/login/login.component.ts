import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserService } from '../login-service.service';
import {User} from '../user.model';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-login',
  providers: [UserService],
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {
  users: User[];
  role: String;
  isValid:boolean;
  msg:any;
  user!: User;
  

  profileForm = new FormGroup({
    username: new FormControl(''),
    password: new FormControl('')
  });
 
  constructor(private userService: UserService,  private route: ActivatedRoute,
    private router: Router) { 
   this.users=[];
   this.role="";
   this.isValid=false;
   this.msg="";
  
  }
    
  ngOnInit(): void {

    this.msg = this.route.snapshot.params['message'];
    
    console.log(this.msg);
    this.userService.findAll().subscribe(data => {
      this.users = data;
    });
     
  }

  onSubmit() {
    // TODO: Use EventEmitter with form value
    console.log(this.profileForm.value);
    console.log(this.users);
    this.role="";
    this.isValid=false;
    this.users.forEach(element => { 
      if(element.userName == this.profileForm.value.username &&
      element.password == this.profileForm.value.password
      ){
        this.role=element.role;
        this.user=element;
        console.log(this.role);
        this.isValid=true;
      }
    });
      if(this.isValid==false)
      {
        this.router.navigate(['/Login', { message: "invalid" }]);
      }
      if(this.role=="Manager")
      {
        this.router.navigate(['/Manager', { userId: this.user.userId, username:this.user.userName}]);
      }
      if(this.role=="Engineer")
      {
        this.router.navigate(['/Engineer', { userId: this.user.userId, username:this.user.userName}]);
      }
      if(this.role=="Admin")
      {
        this.router.navigate(['/Admin']);
      }
      if(this.role=="Customer")
      {
        this.router.navigate(['/Customer', { userId: this.user.userId, username:this.user.userName}]);
      }
    
  }

}
