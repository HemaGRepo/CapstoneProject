import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { UserService } from '../login-service.service';
import { User } from '../user.model';

@Component({
  selector: 'app-view-user',
  providers: [UserService],
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {

  users: User[];  
 
  constructor(private userService: UserService,  private route: ActivatedRoute,
    private router: Router) { 
   this.users=[];
  
  }
    
  ngOnInit(): void {
    this.userService.findAll().subscribe(data => {
      this.users = data;
    });

  }

  delete(username:any) {
    console.log(username);
    this.userService.deleteByName(username);
   // this.complaintService.deleteById(id);

}


}






