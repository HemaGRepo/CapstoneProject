import { Complaint } from './complaint.model';

describe('Complaint', () => {
  it('should create an instance', () => {
    expect(new Complaint()).toBeTruthy();
  });
});
