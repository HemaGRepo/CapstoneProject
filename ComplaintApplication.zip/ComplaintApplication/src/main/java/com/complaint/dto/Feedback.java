package com.complaint.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Feedback")
public class Feedback {
	
	@Id
	@Column(name = "complaintid")
	int complaintId;

	@Column(name = "score")
	 int score;
	
 public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}
public Feedback(int complaintId, int score) {
		super();
		this.complaintId = complaintId;
		this.score = score;
	}
@Override
	public String toString() {
		return "Feedback [complaintId=" + complaintId + ", score=" + score + "]";
	}
public int getComplaintId() {
		return complaintId;
	}
	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	

}
