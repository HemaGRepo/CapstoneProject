package com.complaint.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table
public class Complaint {
	
	@Id
    @Column(name = "complaintid", updatable = false, nullable = false)
	private Integer complaintId;
	
	@Column(name = "customerid")
	private Integer customerId;
	
	@Column
	private String description;
	
	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Column
	private String pincode;
	
	@Column
	private String status;

	@Override
	public String toString() {
		return "Complaint [complaintId=" + complaintId + ", customerId=" + customerId + ", description=" + description
				+ ", pincode=" + pincode + ", status=" + status + "]";
	}

	public Integer getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(Integer complaintId) {
		this.complaintId = complaintId;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
