package com.complaint.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Assignment {

	@Id
@Column(name = "complaintId")
 int complaintId;
	
@Column(name = "EngineerId")
 int EngineerId;
	
@Column(name = "pincode")
 String pinCode;
 
 public Assignment() {
	super();
	// TODO Auto-generated constructor stub
}

public Assignment(int complaintId, int engineerId, String pinCode) {
	super();
	this.complaintId = complaintId;
	EngineerId = engineerId;
	this.pinCode = pinCode;
}

 
 @Override
public String toString() {
	return "Assignment [complaintId=" + complaintId + ", EngineerId=" + EngineerId + ", pinCode=" + pinCode + "]";
}

 public int getComplaintId() {
	return complaintId;
}
public void setComplaintId(int complaintId) {
	this.complaintId = complaintId;
}
public int getEngineerId() {
	return EngineerId;
}
public void setEngineerId(int engineerId) {
	EngineerId = engineerId;
}
public String getPinCode() {
	return pinCode;
}
public void setPinCode(String pinCode) {
	this.pinCode = pinCode;
}

 
}
