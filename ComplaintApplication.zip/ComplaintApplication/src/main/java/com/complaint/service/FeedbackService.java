package com.complaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.complaint.dao.FeedbackRepository;
import com.complaint.dao.UserRepository;
import com.complaint.dto.Feedback;
import com.complaint.dto.UserEntity;

@Service
public class FeedbackService {
	  @Autowired
	    FeedbackRepository feedbackRepository;
	    
	    RestTemplate restTemplate = new RestTemplate();
	        
		
		public void addFeedback(Feedback pe) {
			 feedbackRepository.save(pe);
			
		}
}
