package com.complaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.complaint.dao.AssignmentRepo;
import com.complaint.dao.ComplaintRepository;
import com.complaint.dao.UserRepository;
import com.complaint.dto.Assignment;
import com.complaint.dto.Complaint;
import com.complaint.dto.UserEntity;

@Service
public class ComplaintService {

	@Autowired
    ComplaintRepository complaintRepository;
	
	@Autowired
	AssignmentRepo assignmentRepository;
    
    RestTemplate restTemplate = new RestTemplate();
    
    public Complaint getComplaint(int ComplaintId) {
		Complaint pr=complaintRepository.findById(ComplaintId).get();
		return pr;
	}
	
	public List<Complaint> getAll() {
		List<Complaint> pr=complaintRepository.findAll();
		return pr;
	}

	public int updateComplaint(Integer id, String status) {
		return complaintRepository.updateStatus(id,status);
		
	}

	public void addComplaint(Complaint pe) {
		complaintRepository.save(pe);	
	}
	
	public void deleteComplaint(Integer id) {
		complaintRepository.deleteById(id);	}
	
	public void addAssignment(Assignment assign) {
		assignmentRepository.save(assign);
	}
}
