package com.complaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.complaint.dao.UserRepository;
import com.complaint.dto.UserEntity;

@Service
public class UserService {
    
    @Autowired
    UserRepository userRepository;
    
    RestTemplate restTemplate = new RestTemplate();
        
	public UserEntity getUser(int UserId) {
		UserEntity pr=userRepository.findById(UserId).get();
		return pr;
	}
	
	public List<UserEntity> getAll() {
		List<UserEntity> pr=userRepository.findAll();
		return pr;
	}

	public int update(String username, String oldPwd, String newPwd) {
	//	return userRepository.updateUser(username,oldPwd,newPwd);
		return 0;
		
	}

	public void addUser(UserEntity pe) {
		 userRepository.save(pe);
		
	}
	
	public void deleteUser(String username) {
		userRepository.deleteById(username);}
}
