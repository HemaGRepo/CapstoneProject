package com.complaint.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.complaint.dto.Assignment;


@Repository
public interface AssignmentRepo extends JpaRepository<Assignment, Integer> {

	 @Autowired 
	 DataSource dSource=new DataSourceConfig().getDataSource();

}