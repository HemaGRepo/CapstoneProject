package com.complaint.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.complaint.dto.Complaint;


@Repository
public interface ComplaintRepository extends JpaRepository<Complaint, Integer> {

	 @Autowired 
	 DataSource dSource=new DataSourceConfig().getDataSource();
	 
	@Transactional
	@Modifying
	@Query("update Complaint p set p.status=?2 where p.complaintId=?1")
	int updateStatus(Integer id, String status);

}
