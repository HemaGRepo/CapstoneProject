package com.complaint.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.complaint.dto.Feedback;
import com.complaint.dto.UserEntity;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Integer> {
	
	
	 @Autowired 
	 DataSource dSource=new DataSourceConfig().getDataSource();


}
