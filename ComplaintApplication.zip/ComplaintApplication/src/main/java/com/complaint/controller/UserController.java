package com.complaint.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.complaint.dto.UserEntity;
import com.complaint.service.UserService;

@CrossOrigin
@RestController
@RequestMapping(path = "/admin")
public class UserController {

    @Autowired
    UserService userservice;
    
    @RequestMapping("/login/{username}/{password}")
    public UserEntity getUser(@PathVariable String username, @PathVariable String password){
        List<UserEntity> users= userservice.getAll();
        UserEntity user=new UserEntity();
        boolean flag=false;
        for(UserEntity ue:users) {
        	if(ue.getUserName().equals(username) && ue.getPassword().equals(password))
        	{
        		user.setUserName(ue.getUserName());
        		user.setPassword(ue.getPassword());
        		user.setRole(ue.getRole());
        		flag=true;
        		break;
        	}
        }
        return user;
    }
    
    
    @RequestMapping("/users")
    public List<UserEntity> getUsers(){
        List<UserEntity> users= userservice.getAll();
        return users;
    }
    
	@DeleteMapping("/delete/{name}")  
    public void deleteUser(@PathVariable String name){
        userservice.deleteUser(name);
    }
   
}

