package com.complaint.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.complaint.dto.Assignment;
import com.complaint.dto.Complaint;
import com.complaint.dto.Feedback;
import com.complaint.dto.UserEntity;
import com.complaint.service.ComplaintService;
import com.complaint.service.FeedbackService;
import com.complaint.service.UserService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ComplaintController {
	
    @Autowired
   ComplaintService complaintservice;
    
    @Autowired
    FeedbackService fbs;

	@RequestMapping("/complaints")
    public List<Complaint> getComplaints(){
        List<Complaint> complaints= complaintservice.getAll();
        return complaints;
    }
	
	@DeleteMapping("/complaint/delete/{id}")  
    public void deleteComplaint(@PathVariable Integer id){
        complaintservice.deleteComplaint(id);
    }
	
	@RequestMapping(method=RequestMethod.POST,value="/feedback")  
    public void providefeedback(@RequestBody Feedback fe ){
		//Feedback fe=new Feedback(id,score);
        fbs.addFeedback(fe);
    }
	
	@RequestMapping(method=RequestMethod.POST,value="/complaint")  
    public void raiseComplaint(@RequestBody Complaint ce ){
       complaintservice.addComplaint(ce);
    }
	
	@RequestMapping(method=RequestMethod.POST,value="/complaint/assign")  
    public void addAssignment(@RequestBody Assignment ae){
		System.out.println(ae);
       complaintservice.addAssignment(ae);
    }
	
	@RequestMapping("/complaint/{id}/{status}")  
    public void updateComplaint(@PathVariable String id,@PathVariable String status){
		System.out.println("Updating...."+id+" - "+status);
        complaintservice.updateComplaint(Integer.parseInt(id), status);
    }
}
